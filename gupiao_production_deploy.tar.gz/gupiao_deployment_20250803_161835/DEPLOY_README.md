# 🚀 股票分析系统部署包

## 📋 包含内容
- 完整应用源代码
- 自动化部署脚本  
- 详细部署文档
- 系统管理工具
- Nginx配置模板

## 🎯 快速部署（CentOS 7.9 + 宝塔）

### 1. 上传解压
```bash
# 上传到服务器并解压
tar -xzf gupiao_deployment_*.tar.gz
cd gupiao_deployment_*
```

### 2. 环境检查
```bash
./check_environment.sh
```

### 3. 一键部署
```bash
sudo ./deploy.sh
```

### 4. 配置API密钥
```bash
vim config/api_keys.py
# 设置: TUSHARE_TOKEN = "your_token_here"
```

### 5. 管理系统
```bash
./manage.sh status    # 查看状态
./manage.sh start     # 启动服务
./manage.sh logs      # 查看日志
```

## 📖 详细文档
- `CENTOS_DEPLOYMENT_GUIDE.md` - 详细部署指南
- `QUICK_DEPLOY_CHECKLIST.md` - 快速部署清单

## 🌐 访问地址
http://your-server-ip:8501

## 🏆 系统特性
- ✅ 5,728只股票全市场覆盖
- ✅ 智能搜索和风险评估
- ✅ Web界面友好易用
- ✅ 自动重启和监控

祝您部署成功！🎉
